<?php
header("content-type:application/json;charset=utf-8;");
function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
}
cors();
//解决跨域问题
$user= 'root';        // mysql username
$pass=''; //PASSWORD--none,有password那个不是xampp的数据库.
$db='art';

//建立连接,获取参数
$link= mysqli_connect('localhost',$user,$pass,$db);
//$current = mysqli_real_escape_string($link, $_GET['current']);

$ID=$_GET['ArtistID'];

//print_r($_GET);
$sql_total="SELECT LastName,FirstName FROM artists WHERE ArtistID = '$ID'";
$total=mysqli_fetch_all(mysqli_query($link,$sql_total),MYSQLI_ASSOC);

$response = array(
    'LastName'=> $total[0]['LastName'],
    'FirstName'=> $total[0]['FirstName'],
);

echo json_encode($response);