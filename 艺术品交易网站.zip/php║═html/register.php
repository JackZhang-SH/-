<?php
//包括注册和登录的后端操作


header("content-type:text/json;charset=utf-8");
function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
}
cors();

$user= 'root';        // mysql username
$pass=''; //PASSWORD--none,有password那个不是xampp的数据库.
$db='art';

//建立连接
$link= mysqli_connect('localhost',$user,$pass,$db);


//login表单要提交的数据
$PostData= json_decode(file_get_contents('php://input'), true);
$name = mysqli_real_escape_string($link, $PostData['name']);
$password = mysqli_real_escape_string($link, $PostData['password']);
$email = mysqli_real_escape_string($link, $PostData['email']);
$address = mysqli_real_escape_string($link, $PostData['address']);
$tel = mysqli_real_escape_string($link, $PostData['tel']);


//若用户名和邮箱不存在，则增加一行数据
$checkName="SELECT * from user WHERE name='$name' ";
$resName=mysqli_query($link,$checkName);
$dataName=mysqli_fetch_all($resName,MYSQLI_ASSOC);
$checkEmail="SELECT * from user WHERE email='$email' ";
$resEmail=mysqli_query($link,$checkEmail);
$dataEmail=mysqli_fetch_all($resEmail,MYSQLI_ASSOC);
$add="INSERT INTO `user` (`name`, `password`, `email`, `tel`, `address`) VALUES ('$name', '$password', '$email', '$tel','$address')";


if(count($dataName)||count($dataEmail)) {
    //失败
    $response = array(
        'code' => '204',
    );
}
else{
    //成功
    mysqli_query($link,$add);
    $response= array(
        'code'=>'203',
    );
}
echo json_encode($response);;


?>