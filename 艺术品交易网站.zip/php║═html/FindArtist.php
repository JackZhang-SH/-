<?php
$user= 'root';        // mysql username
$pass=''; //PASSWORD--none,有password那个不是xampp的数据库.
$db='art';
header("charset=utf-8");
//建立连接
$link= mysqli_connect('localhost',$user,$pass,$db);
$sql_current = "SELECT * FROM paintings";
$total= mysqli_fetch_all(mysqli_query($link, $sql_current), MYSQLI_ASSOC);
for($i=0;$i<count($total);$i++){
    $artistID=$total[$i]['ArtistID'];
    $paintingID=$total[$i]['PaintingID'];
    $sql_artist="SELECT * FROM artists WHERE ArtistID ='$artistID'";
    $data= mysqli_fetch_all(mysqli_query($link, $sql_artist), MYSQLI_ASSOC);
    $artist=$data[0]['FirstName'].' '.$data[0]['LastName'];
    $sql_update="update paintings set Artist='$artist' where PaintingID='$paintingID'";
    mysqli_query($link,$sql_update);
    echo  count($total);
};
