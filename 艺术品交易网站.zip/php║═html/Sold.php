<?php
header("content-type:application/json;charset=utf-8;");
//解决跨域问题
function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

};
cors();
$user= 'root';        // mysql username
$pass=''; //PASSWORD--none,有password那个不是xampp的数据库.
$db='art';
//建立连接
$link= mysqli_connect('localhost',$user,$pass,$db);
$PostData= json_decode(file_get_contents('php://input'), true);
$PaintingID = mysqli_real_escape_string($link, $PostData['PaintingID']);

$sql_PaintingID = "SELECT * FROM paintings WHERE  PaintingID='$PaintingID'";
$res=mysqli_query($link,$sql_PaintingID);
$data=mysqli_fetch_all($res,MYSQLI_ASSOC);
$name = mysqli_real_escape_string($link, $PostData['name']);
$update_ownerOfPaint="update paintings set Owner = '$name' where PaintingID='$PaintingID'";
$title=$data[0]['Title'];
$Cost=$data[0]['Cost'];
$Time=date("Y.m.d");
//汇款,订单中，如果有owner，那么owner成为seller，否则seller空着。
if(isset($data[0]['Owner'])){
    $owner=$data[0]['Owner'];
    $cost=$data[0]['Cost'];
    $update_owner="update user set account=account+$cost where name='$owner'";
    mysqli_query($link, $update_owner);
    $sql_order="INSERT INTO `purchase_order` (`Time`, `Title`, `Cost`,`Buyer`,`Seller`) VALUES ('$Time', '$title', '$Cost','$name','$owner')";
    mysqli_query($link, $sql_order);
}
else{
    $sql_order="INSERT INTO `purchase_order` (`Time`, `Title`, `Cost`,`Buyer`) VALUES ('$Time', '$title', '$Cost','$name')";
    mysqli_query($link, $sql_order);
}
$update_paint="update paintings set State='已售出' where PaintingID='$PaintingID'";
mysqli_query($link, $update_paint);
$response= array(
    'code'=>'209',
);
//改变owner
mysqli_query($link, $update_ownerOfPaint);
echo  json_encode($response);