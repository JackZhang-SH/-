//给出发布信息
function Published(name){
    fetch('http://localhost:8080/FindPublisher.php?name=' + name, { method: 'GET' })
    .then((response) => response.json())
    .then((dataTable) => {
        showPublished(dataTable);
    });
}

function showPublished(data){
    const publish=document.getElementById('publish');
    let str=`<p>我发布的艺术品:</p>`;
    for(let i=0;i<data.length;i++){
        if(data[i].Publisher==data[i].Owner){
            str+=`                <div class="item">
            <p>艺术品名称：<span>${data[i].Title}</span></p>
            <p>发布日期：<span>${data[i].Time}</span></p>
            <button id="open" onclick="changeForm(${data[i].PaintingID})">修改</button>
            <button onclick='DeleteThisPaint(${data[i].PaintingID})'>删除</button>
        </div>`
        }
        else{
            str+=`                <div class="item">
            <p>艺术品名称：<span>${data[i].Title}</span></p>
            <p>发布日期：<span>${data[i].Time}</span></p>
        </div>`
        }
    }
    publish.innerHTML=str;
}

function Purchased(name){
    fetch('http://localhost:8080/FindOrder.php?name=' + name, { method: 'GET' })
    .then((response) => response.json())
    .then((dataTable) => {
        showPurchased(dataTable);
    });
}

function showPurchased(data){
    const deal=document.getElementById('deal');
    let str=`<p>我购买的艺术品:</p>`;
    for(let i=0;i<data.length;i++){
        str+=`                <div class="item">
        <p>订单编号：<span>${data[i].id}</span></p>
        <p>商品名称：<span>${data[i].Title}</span></p>
        <p>订单时间：<span>${data[i].Time}</span></p>
        <p>订单金额：<span>${data[i].Cost}</span></p>
    </div>`
    }
    deal.innerHTML=str;
}

function DeleteThisPaint(PaintingID){
    fetch('http://localhost:8080/DeleteYourPaint.php?PaintingID=' + PaintingID, { method: 'GET' })
    .then((response) => response.json())
    .then((dataTable) => {
            if(dataTable.code=='215'){
                alert('删除成功');
            }
            window.location.reload();
    });    
}
function Sold(name){
    fetch('http://localhost:8080/FindSeller.php?name=' + name, { method: 'GET' })
    .then((response) => response.json())
    .then((dataTable) => {
        showSold(dataTable);
    });
}

function showSold(data){
    const selling=document.getElementById('selling');
    let str=` <p>我卖出的艺术品:</p>`;
    for(let i=0;i<data.length;i++){
        str+=`                <div class="item">
        <p>艺术品名称：${data[i].Title}</p>
        <p>卖出日期：${data[i].Time}</p>
        <p>售价：${data[i].Cost}</p>
        <p>购买人：${data[i].name}</p>
        <p>购买人邮箱：<span>${data[i].email}</span></p>
        <p>购买人电话：<span>${data[i].tel}</span></p>
        <p>购买人地址：<span>${data[i].address}</span></p>
    </div>`
    }
    selling.innerHTML=str;
}

Published(sessionStorage.name);
Purchased(sessionStorage.name);
Sold(sessionStorage.name);




let chargeForm = document.getElementById("chargeForm");
chargeForm.addEventListener("submit", e => {
    e=e||window.Event;
    e.preventDefault();
    const amount=chargeForm['amount'].value;
    const jsonheaders=new Headers({
        'Content-type':'application/json',
        'Access-Control-Allow-Origin':'http://127.0.0.1:8084',
    });
    const formBody=JSON.stringify({
        amount:amount,
        name:sessionStorage.name,
    })
    console.log(formBody);
    let charge=document.getElementById('amount');
    if(charge.validity.valid == true){
        fetch('http://localhost:8080/charge.php',{
            method:'POST',
            body:formBody,
            headers:jsonheaders,
        })
        .then((response) => response.json())
        .then((data) => {
            
            //根据返回状态code判断是否成功登录
            if(data.code==='208'){
                alert("充值成功");  
                window.location.reload();
            }
        });
    }
    else{
        alert('输入格式不正确');  
    }
})

function noteOR(item, name) {
    let origin = document.getElementById(item);
    let target = document.getElementById(name);
    if (origin.validity.valid != true) {
        if (name === "password_invalid") {
            target.innerText = "密码长度必须大于等于 6 位，且不得为纯数字";
        }
        else if (name === "username_invalid") {
            target.innerText = "用户名只能包含大小写字母、数字、_、-";
        }
        else if (name === "no_amount") {
            target.innerText = "充值金额必须为数字";
        }
        else if (name === "repassword_invalid") {
            target.innerText = "不可为空";
        }
        else if (name === "email_invalid") {
            target.innerText = "邮箱格式不正确";
        }
        else if (name === "tel_invalid") {
            target.innerText = "电话号码不正确";
        }
        else if (name === "address_invalid") {
            target.innerText = "地址不正确";
        }
        else if (name === "no_id") {
            target.innerText = "请输入用户名或邮箱";
        }
        else if (name === "no_password") {
            target.innerText = "请输入密码";
        }        
    }
    else {
        target.innerText = "";
        myValid = true;
        RepasswordCheck();
        passwordCheck();
    }
}

function showAccount(name){
    //异步请求获取值，必须在异步函数中调用await等到它被获取。
    // let amount = fetch('http://localhost:8080/account.php?name=' + name, { method: 'GET' })
    //     .then((response) => response.json())
    //     .then((data) => {
    //         return data;
    //     });
    // let n = await amount;
    // console.log(n)
    // return n;
    var xhr = new XMLHttpRequest();
    console.log(xhr.readyState);//准备状态
    //打开请求
    xhr.open('GET', 'http://localhost:8080/account.php?name=' + name, false); //同步请求
    // 发送请求
    xhr.send(null);
    // 判断响应状态
    let obj = JSON.parse(xhr.responseText);
    console.log(xhr.responseText)
    return obj;
}

function showUser(){
    let user =document.getElementsByClassName('user')[0];
    let data=showAccount(sessionStorage.name);
    user.innerHTML=`<p>用户名：<span>${data.name}</span></p>
    <p>邮箱：<span>${data.email}</span></p>
    <p>电话：<span>${data.tel}</span></p>
    <p>地址：<span>${data.address}</span></p>
    <p>账户余额：<span>${data.account}</span></p>
    <button id="charge">充值</button>`;
}
showUser();
//用户菜单显示
var navbar =document.getElementById("navbar");
var menu =document.getElementById("menu");
var flag=0;

window.onscroll = function(){
    if(window.pageYOffset>=(menu.offsetTop+20)){
        navbar.classList.add("sticky");
    }
    else{
        navbar.classList.remove("sticky");
    }
}

function showList(){
    flag++;
    console.log(flag);
    if(flag%2==0){
        let hidden=document.getElementById("hidden");
        hidden.style.opacity="0";
        hidden.style.width="0";
        hidden.style.height="0";
        hidden.style.overflow="hidden";
        console.log(hidden.style.transition);
    }
    else{
        let hidden=document.getElementById("hidden");
        hidden.style.opacity="1";
        hidden.style.width="auto";
        hidden.style.height="auto";
        hidden.style.overflow="visible";
        console.log(hidden.style.transition);
    }
}

//弹窗
        // 打开弹窗
        var button = document.getElementById("open");
        button.onclick = function(){
	        var modal = document.querySelector(".modal");
            modal.style.display = "block";
        }
        var button_another = document.getElementById("another_open");
        button_another.onclick = function(){
	        var modal = document.querySelector(".modal");
            modal.style.display = "block";
        }
        // 点击取消 关闭弹窗
        var paint_cancel = document.getElementById("paint_cancel");
        paint_cancel.onclick = function(){
	        var modal = document.querySelector(".modal");
            modal.style.display = "none";
            let uploadForm = document.getElementById("uploadForm");
            let img=document.getElementById("photo");
            img.src='../assets/1.jpg';
            uploadForm.reset();
        }

        var charge = document.getElementById("charge");
        charge.onclick = function(){
	        var charge = document.querySelector(".charge");
            charge.style.display = "block";
            
        }
        // 点击取消 关闭弹窗
        var charge_cancel = document.getElementById("charge_cancel");
        charge_cancel.onclick = function(){
	        var charge = document.querySelector(".charge");
            charge.style.display = "none";
        }
        var charge_admit = document.getElementById("charge_admit");
        charge_admit.onclick = function(){
            var msg = "确认充值？";
            if (confirm(msg)==true){
                var charge = document.querySelector(".charge");
                charge.style.display = "none"; //你也可以在这里做其他的操作
            }
        }